package com.example.pizzaria;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

public class Resultado extends AppCompatActivity {

    private TextView textView11, textView12, textView14, textView13;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        textView11 = findViewById(R.id.textView11); // recupera a referência da TextView
        String valorEntrada = getIntent().getStringExtra("VALOR_ENTRADA"); // recupera o valor da Intent

        // define o texto na TextView
        textView11.setText(valorEntrada);




        textView12 = findViewById(R.id.textView12); // recupera a referência da TextView
        String valorEntrada2 = getIntent().getStringExtra("VALOR_ENTRADA2"); // recupera o valor da Intent

        // define o texto na TextView
        textView12.setText(valorEntrada2);



        textView14 = findViewById(R.id.textView14); // recupera a referência da TextView
        String valorEntrada3 = getIntent().getStringExtra("VALOR_ENTRADA3"); // recupera o valor da Intent

        // define o texto na TextView
        textView14.setText(valorEntrada3);


        textView13 = findViewById(R.id.textView13); // recupera a referência da TextView
        String valorEntrada4 = getIntent().getStringExtra("VALOR_ENTRADA4"); // recupera o valor da Intent

        // define o texto na TextView
        textView13.setText(valorEntrada4);

    }
}